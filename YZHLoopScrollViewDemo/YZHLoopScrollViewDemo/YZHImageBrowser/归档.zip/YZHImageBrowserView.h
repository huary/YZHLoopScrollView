//
//  YZHImageBrowserView.h
//  YZHLoopScrollViewDemo
//
//  Created by yuan on 2019/8/6.
//  Copyright © 2019 yuan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YZHLoopScrollView.h"

NS_ASSUME_NONNULL_BEGIN

@interface YZHImageBrowserView : UIView

@property (nonatomic, strong) YZHLoopScrollView *imageScrollView;

@end

NS_ASSUME_NONNULL_END
