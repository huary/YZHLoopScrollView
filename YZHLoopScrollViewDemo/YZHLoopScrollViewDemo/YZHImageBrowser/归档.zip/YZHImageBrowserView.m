//
//  YZHImageBrowserView.m
//  YZHLoopScrollViewDemo
//
//  Created by yuan on 2019/8/6.
//  Copyright © 2019 yuan. All rights reserved.
//

#import "YZHImageBrowserView.h"

@implementation YZHImageBrowserView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        [self _setupImageBrowserViewChidView];
    }
    return self;
}

//-(void)layoutSubviews
//{
//    [super layoutSubviews];
//    self.imageScrollView.frame = self.bounds;
//}

- (YZHLoopScrollView*)imageScrollView
{
    if (_imageScrollView == nil) {
        _imageScrollView = [YZHLoopScrollView new];
    }
    return _imageScrollView;
}

- (void)_setupImageBrowserViewChidView
{
    self.backgroundColor = [UIColor whiteColor];
    [self addSubview:self.imageScrollView];
}

@end
